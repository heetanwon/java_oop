package ezen.ams;

public class ArrayAccountRepository implements AccountRepository {

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Account[] getAccounts() {
		return count;
	}
	

	@Override
	public void addAccount(Account account) {
		accounts[count++] = account;
		

	}

	@Override
	public Account findByNumber(String number) {
		for (int i = 0; i < count; i++) {
			String an =accounts[i].getAccountNumber();
			//동일 계좌번호 여부 확인
			if(an.equals(number)) {
			   return accounts[i];
			}
		}
		return null;
	}
	
	@Override
	public boolean removeAccount(String number) {
		for (int i = 0; i < count; i++) {
			String aa = accounts[i].getAccountNumber();
			if(aa.equals(number) ) {
				for (int j = i; j < count-1; j++) {
					accounts[j] = accounts[j+1];
				}
				count --;
				return true;
			}
			
		}
		
		 		return false;
	}
}
