package ezen.ams;

public class File_Account_repository implements AccountRepository {

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Account[] getAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addAccount(Account account) {
		// TODO Auto-generated method stub

	}

	@Override
	public Account findByNumber(String number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeAccount(String number) {
		// TODO Auto-generated method stub
		return false;
	}

}
