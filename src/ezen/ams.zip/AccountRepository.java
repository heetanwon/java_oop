package ezen.ams;



/**
 * @author 김희원
 *2023. 1. 2.
 *계좌 저장소 객체
 *여러개의 계좌를 저장하고 관리(추가,검색,수정,삭제)하는 역할의 클래스
 */
    public interface AccountRepository {
  
    	

    	public Account[] getAccounts();
    	//계좌목록
    	
    	public int getCount();
    	//계좌의 개수
    	
    	//계좌 등록 기능 
    	public void addAccount(Account account);
    	
    	
    	
    	
    	
    	
    	//계좌 검색 기능 
    	public Account findByNumber(String number);
    	
    	//계좌 삭제 기능
    	public boolean removeAccount();
    	
    	
    	
    	//삭제 알고리즘 
    	

    	//public void setAccounts(Account[] accounts) {
    		//this.accounts = accounts;
    	//}
    	//값을 새로 설정해주는 것이기 때문에 위험 부담이 있음. 프로그램 로직상
    	//세터가 없어도 되는거면 과감하게 삭제해도 상관이 x.
    	
    	
    	
    	
    	
    	
    	
	
	
	
	
}
